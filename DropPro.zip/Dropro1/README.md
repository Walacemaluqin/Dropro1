# DropPro
Starter profissional enxuto para painel de dropshipping.

## Rodar localmente
1. Instale Node.js 20+.
2. Rode `npm install`.
3. Rode `npm start`.
4. Abra `http://localhost:3000`.

## Render
Build Command: `npm install`
Start Command: `npm start`
Environment: `DATABASE_URL` e credenciais oficiais das integrações.

## Importante
Este pacote é uma base inicial. A integração de produção com Mercado Livre e Shopee exige credenciais de aplicativo, OAuth, webhooks e validações oficiais antes de operar pedidos reais.
